import React from 'react';

const Users = () => {
  return (
    <div>
      <h1>This is the Users Page</h1>
    </div>
  );
};

export default Users;
