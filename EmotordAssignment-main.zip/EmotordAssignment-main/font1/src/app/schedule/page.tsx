import React from 'react';

const Schedules = () => {
  return (
    <div>
      <h1>This is the Schedules Page</h1>
    </div>
  );
};

export default Schedules;
