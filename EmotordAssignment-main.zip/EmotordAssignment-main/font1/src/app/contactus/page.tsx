import React from 'react';

const ContactUs = () => {
  return (
    <div>
      <h1>This is the Contact Us Page</h1>
    </div>
  );
};

export default ContactUs;
