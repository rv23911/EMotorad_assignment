import React from 'react';

const Settings = () => {
  return (
    <div>
      <h1>This is the Settings Page</h1>
    </div>
  );
};

export default Settings;
