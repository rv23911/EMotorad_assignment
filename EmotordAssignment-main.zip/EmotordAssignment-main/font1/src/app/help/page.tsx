import React from 'react';

const Help = () => {
  return (
    <div>
      <h1>This is the Help Page</h1>
    </div>
  );
};

export default Help;
