import React from 'react';

const Transactions = () => {
  return (
    <div>
      <h1>This is the Transactions Page</h1>
    </div>
  );
};

export default Transactions;
