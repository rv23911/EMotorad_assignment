import React from 'react';

const AddProfile = () => {
  return (
    <div>
      <h1>This is the Add Profile Page</h1>
    </div>
  );
};

export default AddProfile;
